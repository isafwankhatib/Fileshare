﻿New-Variable -Name 'SYS_MSG_CONSTANT' -Value '-*-microservices-*-' -Option Constant

New-Variable -Name 'SYS_VAULT_CONF_FILE_CONSTANT' -Scope Global

New-Variable -Name 'SYS_EXECID_CONSTANT' -Scope Global

New-Variable -Name 'SYS_TEMP_FOLDER_CONSTANT' -Scope Global

New-Variable -Name 'SYS_MASTER_KEYSTORE_PATH_CONSTANT' -Scope Global

New-Variable -Name 'SYS_MASTER_KEYSTORE_PASS_CONSTANT' -Scope Global

New-Variable -Name 'SYS_MASTERVAULT_CERT_LOGIN_URI_CONSTANT' -Scope Global

New-Variable -Name 'SYS_SSL_PROTOCOL_SUPPORT_CONSTANT' -Scope Global

New-Variable -Name 'SYS_MASTERVAULT_PLUGIN_DISPLAYNAME_CONSTANT' -Scope Global

New-Variable -Name 'SYS_INSTALL_CERTFICATE_FILEPATH_CONSTANT' -Scope Global

New-Variable -Name 'SYS_VAULT_BASEADDR_CONSTANT' -Scope Global

New-Variable -Name 'SYS_VAULT_BASE_MOUNT_TYPE_CONSTANT' -Scope Global


function global:Set-ExecId( [parameter(Position=0,Mandatory=$true)][string]$execId)
{

    Set-Variable -Name 'SYS_EXECID_CONSTANT' -Value $execId -Scope Global

}

function global:Set-TempFolder( [parameter(Position=0,Mandatory=$true)][string]$folder)
{

    Set-Variable -Name 'SYS_TEMP_FOLDER_CONSTANT' -Value $folder -Scope Global

}

function global:Set-VaultVariables([parameter(Position=0,Mandatory=$true)][string]$confFilePath)
{
    [xml] $confFile = Get-Content $confFilePath
    
    Set-Variable -Name 'SYS_MASTER_KEYSTORE_PATH_CONSTANT' -Value $confFile.configuations.vault.masterKeystorePath -Scope Global
    
    Set-Variable -Name 'SYS_MASTER_KEYSTORE_PASS_CONSTANT' -Value $confFile.configuations.vault.masterKeystorePass -Scope Global
    
    Set-Variable -Name 'SYS_MASTERVAULT_CERT_LOGIN_URI_CONSTANT' -Value $confFile.configuations.vault.masterVaultCertLoginURI -Scope Global
    
    Set-Variable -Name 'SYS_SSL_PROTOCOL_SUPPORT_CONSTANT' -Value $confFile.configuations.vault.sslProtocolSupport -Scope Global
    
    Set-Variable -Name 'SYS_MASTERVAULT_PLUGIN_DISPLAYNAME_CONSTANT' -Value $confFile.configuations.vault.masterVaultPluginDisplayName -Scope Global
    
    Set-Variable -Name 'SYS_INSTALL_CERTFICATE_FILEPATH_CONSTANT' -Value $confFile.configuations.vault.installCertFilePath -Scope Global
    
    Set-Variable -Name 'SYS_VAULT_BASEADDR_CONSTANT' -Value $confFile.configuations.vault.vaultBaseAddr -Scope Global
    
    Set-Variable -Name 'SYS_VAULT_BASE_MOUNT_TYPE_CONSTANT' -Value $confFile.configuations.vault.vaultBaseMountType -Scope Global
}

###Reads inputs in JSON & converts it to Hash Table & returns the Hash Table####

function global:Read-Input( [parameter(Position=0,Mandatory=$true)][string]$inputs)
{

 <#
       .SYNOPSIS 
            Reads Input into a hashtable
        
        .PARAMETER input
            input. Read-Input gets input in JSON format
        

        .OUTPUT
            Hashtable. Read-Input returns a hashtable of the read inputs

        .EXAMPLE
           C:\PS> Read-Input -input "{"key":"value"}"

         
      #>
    #"input received as $inputs"
    try
    {
        if ([string]::IsNullOrEmpty($inputs))
        {
            Write-Output "no input found"
        }
        else
        {
           # $inputs = '{"key":"value"}'
            $hashInput = @{}
          $jsonObj = $inputs | ConvertFrom-Json
            #Write-Output 'input received as '$inputs
            #Write-Output 'hard code' $inputs
            #Write-Output 'json is' $jsonObj
            
            foreach ($property in $jsonObj.PSObject.Properties) 
            {
                $hashInput[$property.Name] = $property.Value
                #Write-Output 'Hashtable Created'
            }
        
            foreach ($key in $hashInput.Keys) 
            {
                $value = $hashInput.Values                      # or
                #$value = $var.$key 
               # Write-Output "$key : $value"
            }
            #return $hash
            #"$hashInput"
            return $hashInput
        }
    }
    catch  
    {
        $out = "##ERROR## Error Occurred. The Error was $_.Exception.Message"
        return $out
    }
}

###Logging for script along with Log Level####

function global:Write-Log()
{
    param(
    [parameter(Position=0,Mandatory=$true)][int]$logLevel,
    [parameter(Position=1,Mandatory=$true)][string]$logMsg
    )
$date = Get-Date
    try
    {
        <#
           .SYNOPSIS 
                Write log.
        
            .PARAMETER logLevel
                Log Level

                1 - FATAL
                2 - ERROR
                3 - WARN
                4 - INFO
                5 - DEBUG
                6 - TRACE
        
            .PARAMETER logMsg
                Message to logged

            .EXAMPLE
               C:\PS> Write-Log -logLevel 1 -logMsg "Script terminated"

         
          #>
          $a = (get-date).millisecond
          $date = Get-Date -Format "yyyy-MM-dd hh:mm:ss.$a"
        #$date = Get-Date -Format "yyyy-mm-dd hh:mm:ss.$($(get-date).millisecond)"
        switch($logLevel)
        {
            1{ $log = "##WL##$date#FATAL#$logMsg" }
            2{ $log = "##WL##$date#ERROR#$logMsg" }
            3{ $log = "##WL##$date#WARN#$logMsg" }
            4{ $log = "##WL##$date#INFO#$logMsg" }
            5{ $log = "##WL##$date#DEBUG#$logMsg" }
            6{ $log = "##WL##$date#TRACE#$logMsg" }
            default{ $log = "##WL##$date#ERROR#$logMsg" }
            
        }
       
        $log
    }
    catch  
    {
        $out = "##ERROR## Error Occurred. The Error was $_.Exception.Message"
		$out
    }
}

###Sending Feedback of Script as required####

function global:Send-Feedback()
{
    param(
        [parameter(Position=0,Mandatory=$true)][int]$fbpercent,
        [parameter(Position=1,Mandatory=$true)][string]$fbMsg
     )

    try
    {
         <#
       .SYNOPSIS 
            Sends script feedback.
        
        .PARAMETER fbpercent
            How much percent of script is completed
        
        .PARAMETER fbMsg
            Message to be sent as feedback

        .EXAMPLE
           C:\PS> Send-Feedback -fbpercent 10 -fbMsg "This is a script feedback"

         
      #>
         $a = (get-date).millisecond
         $date = Get-Date -Format "yyyy-MM-dd hh:mm:ss.$a"
         $fb = "##SFB##$date#$fbpercent#$fbMsg"
        return $fb
    }
    catch  
    {
        $out = "##ERROR## Error Occurred. The Error was $_.Exception.Message"
		$out
    }
}

###Checking if Mandatory inputs send by script is present or not####

function global:Get-MandatVars()
{
    param(
        [parameter(Position=0,Mandatory=$true)][hashtable]$inputs,
        [parameter(Position=1,Mandatory=$true)][string[]]$mandatInputs
    )
    try
    {
         <#
       .SYNOPSIS 
            Return array of mandatory variable names missing in the hashtable
        
        .PARAMETER ht
            Hash table to be checked for mandatory variables
        .PARAMETER names
            Array of mandatory variable names
        .OUTPUTS
           string[]. Get-MandatInputs returns an array of missing variable names

        .EXAMPLE
           C:\PS> Get-MandatVars -inputs $inputs -mandatInputs @('ip_addr','port_no')

         
      #>

        [string[]]$vars=@()
        foreach($name in $mandatInputs)
        {
            if(-not ($inputs.ContainsKey($name)))
            {
               $vars+=$name
            }
            else 
            {
                if(   $inputs.Get_Item($name).trim() -eq "")
                {
                    $vars+=$name
                }
            }
        }
        return $vars

        
    }
    catch  
    {
        $out = "##ERROR## Error Occurred. The Error was $_.Exception.Message"
		$out
    }
}

###Sending Output along with logging of Script####

function global:Send-Output()
{
    param(
    [parameter(Position=0,Mandatory=$true)][string]$retCode,
    [parameter(Position=1,Mandatory=$true)][string]$retDesc,
    [parameter(Position=2,Mandatory=$false)][hashtable]$output
    )
    $ret=$null
    try
    {
         <#
           .SYNOPSIS 
                Writes Output
        
            .PARAMETER logMsgs
                Collects all the log messages of the script
                                

            .PARAMETER output
                Hashtable to be converted to JSON & send as output
        

            .EXAMPLE
               C:\PS> Send-Output -retCode<rectCode> -retDesc<retDesc> -output @{} 

         
          #>

        $finalOutput = @{}
        $output
        if($output -ne $null)
        {
            $finalOutput = $output
            $finalOutput.Add("retCode",$retCode)
            $finalOutput.Add("retDesc",$retDesc)
        }
        else
        {
            $finalOutput.Add("retCode",$retCode)
            $finalOutput.Add("retDesc",$retDesc)
        }
        $outJson = ConvertTo-Json $finalOutput -Compress
                        
       $out = "##SO##$outJson" | Out-String
	   return $out
	break
    }
    catch  
    {
        $out = "##ERROR## Error Occurred. The Error was $_.Exception.Message"
	    return $out
    }
}

### Request to send document from Script####

function global:Request-Doc()
{
    param(
        [parameter(Position=0,Mandatory=$true)][int]$documentID,
        [parameter(Position=1,Mandatory=$true)][int]$timeout,
        [parameter(Position=2,Mandatory=$true)][string]$destinationFile
      )

     <#
           .SYNOPSIS 
                Sends the Request to Portal for downloading document
                                
            .PARAMETER documentID
                The ID of docuemnt to be downloaded
                
            .SYNTAX
               C:\PS> Request-Doc -documentID <documentID> -timeout <timeout if download fails in mins> -destinationFile <Absolute Path of file at destination>
         
    #> 

        $dl = "##DLDOC##$destinationFile#$documentID#$timeout"  
        $dl
}    


function global:WaitForDoc()
{
    <#
        .SYNOPSIS
            Wait for document to Download

        .SYNTAX
            C:\PS> $retJson = WaitForDoc
    #>

    try
    {
        
        $tempPath= Get-Variable -Name 'SYS_TEMP_FOLDER_CONSTANT' -ValueOnly -Scope Global
        
        $scrptExecId = Get-Variable -Name 'SYS_EXECID_CONSTANT' -ValueOnly -Scope Global		

        $tempFile="$($tempPath)\\$($scrptExecId).json"
		
        While (!(Test-Path $tempFile -ErrorAction SilentlyContinue))
            {
                # endless loop, when the file will be there, it will continue
            }
			
                $json = Get-Content -Path $tempFile | ConvertFrom-Json
                Remove-Item $tempFile
                return $json
      }
    
    catch  
       {
        $json=@{}
        $json.Add("retCode",1)
        $json.Add("retDesc","Failed to get document")
        $out = "##ERROR## Error Occurred. The Error was $_.Exception.Message"
		$out
        }
}

### Installing Certificate in Trusted Root Authority of Local Machine ###

function global:Install-VaultCert()
{
    param(
        [parameter(Position=0,Mandatory=$true)][System.Security.Cryptography.X509Certificates.X509Certificate2]$certificate
    )
    
    <#
       .SYNOPSIS 
            Add the certificate for authenticating login to Vault (.crt format) to Trusted Root Authority in Local Machine.
            Internal Method: Not exposed outside
       
       .PARAMETER
           X509Certificate to be added to the root(.crt format)

        .EXAMPLE
           C:\PS> Install-VaultCert -certificate $certificate
 
    #>

    try
    {
        $store = New-Object System.Security.Cryptography.X509Certificates.X509Store([System.Security.Cryptography.X509Certificates.StoreName]::Root,"localmachine")
        
        $store.Open([System.Security.Cryptography.X509Certificates.OpenFlags]::ReadWrite)

        $store.Add($certificate)

        $store.Close()
    }

    catch
    {
        $err = "##ERROR## Error occured. The error was $_.Exception.Message"
        $err
    }
}

### Fetching Auth Token from Vault Server ####

function global:Get-VaultToken()
{
    <#
       .SYNOPSIS 
            Fetch the auth token from master vault server.

        .EXAMPLE
           C:\PS> $vaultToken = Get-VaultToken

           ******* Deprecated method ******** DONOT USE *****
 
      #>

    try{
        
        $installCertFilePath = Get-Variable -Name 'SYS_INSTALL_CERTFICATE_FILEPATH_CONSTANT' -ValueOnly -Scope Global

        $masterKeystorePath = Get-Variable -Name 'SYS_MASTER_KEYSTORE_PATH_CONSTANT' -ValueOnly -Scope Global
        
        $masterKeystorePass = Get-Variable -Name 'SYS_MASTER_KEYSTORE_PASS_CONSTANT' -ValueOnly -Scope Global
        
        $masterVaultCertLoginURI = Get-Variable -Name 'SYS_MASTERVAULT_CERT_LOGIN_URI_CONSTANT' -ValueOnly -Scope Global
        
        $sslProtocolSupport = Get-Variable -Name 'SYS_SSL_PROTOCOL_SUPPORT_CONSTANT' -ValueOnly -Scope Global
        
        $masterVaultPluginDisplayName = Get-Variable -Name 'SYS_MASTERVAULT_PLUGIN_DISPLAYNAME_CONSTANT' -ValueOnly -Scope Global

        $certFilePath = Get-Variable -Name 'SYS_INSTALL_CERTFICATE_FILEPATH_CONSTANT' -ValueOnly -Scope Global

        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::$sslProtocolSupport

        [System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}

        $masterKeystorePassEncr = ConvertTo-SecureString $masterKeystorePass -AsPlainText -Force

        $installCertificate = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2

        $installCertificate.Import($installCertFilePath,$masterKeystorePass,'DefaultKeySet')

        Install-VaultCert -certificate $installCertificate

        $p12Certificate = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2

        $p12Certificate.Import($masterKeystorePath,$masterKeystorePass,'DefaultKeySet')

        $data = @{ "name" = $masterVaultPluginDisplayName } | ConvertTo-Json

        $response = Invoke-RestMethod -Uri $masterVaultCertLoginURI -Method Post -Certificate $p12Certificate -Body $data

        $VaultToken = $response.auth.client_token

        $VaultToken
      }
      
      catch
      {
        $err = "##ERROR## Error occured. The error was $_.Exception.Message"
        $err
      }
}

### Sendng the decrypted value to the script from vault ####

function global:Decrypt-String()
{
    param(
        [parameter(Position=0,Mandatory=$true)][string]$encryptedString
    )

    <#
       .SYNOPSIS 
            Fetch the auth token from master vault server and then Fetch the decrypted value of the password from Vault using API.

       .PARAMETER
            The string with the UUID to be passed in the format BRAIO_PASSWD#@#<UUID>#@#

        .EXAMPLE
           C:\PS> Decrypt-String -encryptedString "BRAIO_PASSWD#@#4de4846b-4f74-973c-7516-07da41c12fe8#@#"
 
      #>

    try{

        $VaultBaseAddr = Get-Variable -Name 'SYS_VAULT_BASEADDR_CONSTANT' -ValueOnly -Scope Global

        $vaultMountType = Get-Variable -Name 'SYS_VAULT_BASE_MOUNT_TYPE_CONSTANT' -ValueOnly -Scope Global
                
        $installCertFilePath = Get-Variable -Name 'SYS_INSTALL_CERTFICATE_FILEPATH_CONSTANT' -ValueOnly -Scope Global

        $masterKeystorePath = Get-Variable -Name 'SYS_MASTER_KEYSTORE_PATH_CONSTANT' -ValueOnly -Scope Global
        
        $masterKeystorePass = Get-Variable -Name 'SYS_MASTER_KEYSTORE_PASS_CONSTANT' -ValueOnly -Scope Global
        
        $masterVaultCertLoginURI = Get-Variable -Name 'SYS_MASTERVAULT_CERT_LOGIN_URI_CONSTANT' -ValueOnly -Scope Global
        
        $sslProtocolSupport = Get-Variable -Name 'SYS_SSL_PROTOCOL_SUPPORT_CONSTANT' -ValueOnly -Scope Global
        
        $masterVaultPluginDisplayName = Get-Variable -Name 'SYS_MASTERVAULT_PLUGIN_DISPLAYNAME_CONSTANT' -ValueOnly -Scope Global

        $certFilePath = Get-Variable -Name 'SYS_INSTALL_CERTFICATE_FILEPATH_CONSTANT' -ValueOnly -Scope Global
        
        [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12

        [System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}
        <#
            Snippet to get vault token from vault
        #>
        
        $masterKeystorePassEncr = ConvertTo-SecureString $masterKeystorePass -AsPlainText -Force

        $installCertificate = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2

        $installCertificate.Import($installCertFilePath,$masterKeystorePass,'DefaultKeySet')
       
        # --------------- Manual installation now -------------- Install-VaultCert -certificate $installCertificate

        $p12Certificate = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2

        $p12Certificate.Import($masterKeystorePath,$masterKeystorePass,'DefaultKeySet')

        $data = @{ "name" = $masterVaultPluginDisplayName } | ConvertTo-Json

        $response = Invoke-RestMethod -Uri $masterVaultCertLoginURI -Method Post -Certificate $p12Certificate -Body $data -SessionVariable Session

        $VaultToken = $response.auth.client_token

        <#
            Snippet to decrypt string
        #>

        $VaultTokenHeaderKey = "X-Vault-Token";

        # ----------- $VaultToken = Get-VaultToken

        $VaultHeaders = @{ $VaultTokenHeaderKey = $VaultToken }

        $uuid = ($encryptedString -split "#@#")[1]
        
        $VaultUri = $VaultBaseAddr+'/v1/'+$vaultMountType+'/'+$uuid
        
        $result2 = Invoke-RestMethod -Uri $VaultUri -Method Get -Headers $VaultHeaders -WebSession $Session

        $value = $result2.data | Select-Object -ExpandProperty $uuid | select -First 1

        $value

       }
    catch
    {
        $err = "##ERROR## Error occured. The error was $_.Exception.Message"
        return "##ERROR##"  
    }
}

function Enter-StandardRet([parameter(Mandatory=$true)][string]$retDesc)
{
    $return = @{}
    $return.Add("retCode","2")
    $return.Add("retDesc",$retDesc)
    return $return
}

Export-ModuleMember -Function *